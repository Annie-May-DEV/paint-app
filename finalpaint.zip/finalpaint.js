let buttonColors = [
  'red',
  'orange',
  'yellow',
  'green',
  'blue',
  'purple',
  'pink'
];

let currentColor = 'black';
let tool = 'brush'; // brush | eraser
let brushSize = 8;

let sizes = {
  small: 4,
  medium: 8,
  large: 16
};

let canvasLayer;

function setup() {
  createCanvas(400, 400);
  canvasLayer = createGraphics(400, 330);
  canvasLayer.background(225);
}

function draw() {
  background(200);

  // drawing canvas
  image(canvasLayer, 0, 0);

  // toolbar
  drawToolbar();

  // cursor preview
  if (mouseY < canvasLayer.height) {
    noFill();
    stroke(0);
    ellipse(mouseX, mouseY, brushSize);
  }
}

function drawToolbar() {
  fill(240);
  noStroke();
  rect(0, height - 70, width, 70);

  // color buttons
  for (let i = 0; i < buttonColors.length; i++) {
    let x = 35 + i * 45;
    let y = height - 45;

    fill(buttonColors[i]);
    ellipse(x, y, 25);

    if (currentColor === buttonColors[i] && tool === 'brush') {
      stroke(0);
      noFill();
      ellipse(x, y, 30);
      noStroke();
    }
  }

  // eraser button
  fill(220);
  rect(350, height - 60, 35, 25);
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(10);
  text("ERASE", 367, height - 48);

  // size buttons
  drawSizeButton(60, height - 15, "S", sizes.small);
  drawSizeButton(110, height - 15, "M", sizes.medium);
  drawSizeButton(160, height - 15, "L", sizes.large);

  // reset button
  fill(255, 100, 100);
  rect(280, height - 25, 80, 20);
  fill(0);
  text("RESET", 320, height - 15);
}

function drawSizeButton(x, y, label, size) {
  fill(brushSize === size ? 180 : 220);
  rect(x - 15, y - 10, 30, 20);
  fill(0);
  textSize(12);
  textAlign(CENTER, CENTER);
  text(label, x, y);
}

function mouseDragged() {
  if (mouseY > canvasLayer.height) return;

  canvasLayer.strokeWeight(brushSize);
  canvasLayer.strokeCap(ROUND);

  if (tool === 'eraser') {
    canvasLayer.stroke(225);
  } else {
    canvasLayer.stroke(currentColor);
  }

  canvasLayer.line(pmouseX, pmouseY, mouseX, mouseY);
}

function mousePressed() {
  // color selection
  for (let i = 0; i < buttonColors.length; i++) {
    let x = 35 + i * 45;
    let y = height - 45;

    if (dist(mouseX, mouseY, x, y) < 12.5) {
      currentColor = buttonColors[i];
      tool = 'brush';
    }
  }

  // eraser
  if (
    mouseX > 350 &&
    mouseX < 385 &&
    mouseY > height - 60 &&
    mouseY < height - 35
  ) {
    tool = 'eraser';
  }

  // size selection
  if (mouseY > height - 25 && mouseY < height - 5) {
    if (mouseX > 45 && mouseX < 75) brushSize = sizes.small;
    if (mouseX > 95 && mouseX < 125) brushSize = sizes.medium;
    if (mouseX > 145 && mouseX < 175) brushSize = sizes.large;
  }

  // reset
  if (
    mouseX > 280 &&
    mouseX < 360 &&
    mouseY > height - 25 &&
    mouseY < height - 5
  ) {
    canvasLayer.background(225);
  }
}
